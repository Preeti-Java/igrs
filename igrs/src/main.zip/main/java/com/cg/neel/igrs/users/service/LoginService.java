/**
 * 
 */
package com.cg.neel.igrs.users.service;

/**
 * @author Preeti
 *@Des Login Service
 */
public interface LoginService {
	
	

}
