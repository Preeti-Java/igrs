/**
 * 
 */
package com.cg.neel.igrs.users.service;

import java.util.concurrent.ExecutionException;

import javax.validation.Valid;

/**
 * @author Preeti
 *
 */
public interface VerifyCredentialsService {

	/**
	 * @param mobileNumber
	 * @return status Send or not
	 */
	String sendingOtp(final String mobileNumber) throws ExecutionException, InterruptedException;

	/**
	 * @param mobileNumber
	 * @param otp 
	 * @return
	 */
	String verifiedOtp(@Valid String mobileNumber, String otp);

}
