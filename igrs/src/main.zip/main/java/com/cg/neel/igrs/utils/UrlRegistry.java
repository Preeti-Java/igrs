/**
 * 
 */
package com.cg.neel.igrs.utils;

/**
 * @author Preeti
 *
 */
public class UrlRegistry {

}
