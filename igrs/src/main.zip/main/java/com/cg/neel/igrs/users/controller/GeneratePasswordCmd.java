/**
 * 
 */
package com.cg.neel.igrs.users.controller;

/**
 * @author User
 *
 */
public class GeneratePasswordCmd {

}
