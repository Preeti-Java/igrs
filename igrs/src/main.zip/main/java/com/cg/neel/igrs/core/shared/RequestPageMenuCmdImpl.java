package com.cg.neel.igrs.core.shared;





import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;


import com.cg.neel.igrs.core.shared.service.RequestPageService;
import com.cg.neel.igrs.ui.content.MenuAccessBean;


@RestController
public class RequestPageMenuCmdImpl implements RequestPageMenuCmd{
	
	@Autowired
	private RequestPageService requestPageService;
	
	

	@Override
	public List<MenuAccessBean> getSearchMenu() {
		return requestPageService.getSearchMenu();
	}
	

}
