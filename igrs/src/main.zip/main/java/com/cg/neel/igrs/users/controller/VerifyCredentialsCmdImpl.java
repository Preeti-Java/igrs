/**
 * 
 */
package com.cg.neel.igrs.users.controller;

import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.neel.igrs.users.service.VerifyCredentialsService;
import com.cg.neel.igrs.utils.GenericResponse;

/**
 * @author Preeti
 * @Des This class contains all verify method of account 
 *
 */
@RestController
@RequestMapping("/verify")
public class VerifyCredentialsCmdImpl implements VerifyCredentialsCmd{
	
	@Autowired
	private VerifyCredentialsService verifyCredentialsService;

	@Override
	public GenericResponse mobileVerificationBySendingOTP(HttpServletRequest request,final String mobileNumber) throws ExecutionException, InterruptedException {
		final String response = verifyCredentialsService.sendingOtp(mobileNumber);
		
		if(response == null)
			return new GenericResponse("Something issue");
		return new GenericResponse(response);
	}

	@Override
	public GenericResponse mobileVerificationByOTP(HttpServletRequest request, @Valid final String mobileNumber,final String otp) {
		final String response = verifyCredentialsService.verifiedOtp(mobileNumber,otp);
		if(response == null)
			return new GenericResponse("Something issue");
	    return new GenericResponse(response);
	}

}
