package com.cg.neel.igrs.core.shared.service;

import java.util.List;

import com.cg.neel.igrs.searchdata.DistrictAccessBean;


public interface DistrictService {

	List<DistrictAccessBean> getAllDistrict();

	
	
	
}
