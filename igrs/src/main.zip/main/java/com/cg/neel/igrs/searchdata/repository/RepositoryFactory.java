/**
 * 
 */
package com.cg.neel.igrs.searchdata.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author User
 *
 */

@Component
public class RepositoryFactory {
	
	 @Autowired
	    private DistrictRepository districtRepository;

	    @Autowired
	    private TehsilRepository tehsilRepository;
	    
	    @Autowired
	    private VillageRepository villageRepository;
	    
	    @Autowired
	    private RegistrationYearRepository registrationYearRepository;


	    public MappedTypeRepository<?> getRepository(String type) {
	        switch (type) {
	            case "DistrictRepository":
	                return districtRepository;
	            case "TehsilRepository":
	                return tehsilRepository;
	            case "VillageRepository":
	            	return villageRepository;
	            case "RegistrationYearRepository":
	            	return registrationYearRepository;
	            default:
	                throw new IllegalArgumentException("Invalid repository type: " + type);
	        }
	    }

}
