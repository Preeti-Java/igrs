/**
 * 
 */
package com.cg.neel.igrs.users.jwtconfiguration;

/**
 * @author Preeti
 * @Des this interface have two final var -> JWT_key and JWT_Header
 *
 */
public interface SecurityConstants {
	
	public static final String JWT_KEY = "jH+/ZP0OpbZXQpgQZMuZ1u4mYr5SXGyjDvq8Tk/zOcM=";
	public static final String JWT_HEADER = "Authorization";

}
