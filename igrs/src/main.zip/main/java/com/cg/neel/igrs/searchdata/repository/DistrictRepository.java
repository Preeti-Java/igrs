package com.cg.neel.igrs.searchdata.repository;


import org.springframework.stereotype.Repository;

import com.cg.neel.igrs.searchdata.DistrictAccessBean;

@Repository
public interface DistrictRepository extends MappedTypeRepository<DistrictAccessBean>{


}
