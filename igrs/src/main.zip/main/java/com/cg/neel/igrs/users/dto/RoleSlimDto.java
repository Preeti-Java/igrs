/**
 * 
 */
package com.cg.neel.igrs.users.dto;

import lombok.Data;

/**
 * @author Preeti
 * @Des Return and get only roleId
 */

@Data
public class RoleSlimDto {
	
	private Long roleId;

}
