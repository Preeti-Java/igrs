/**
 * 
 */
package com.cg.neel.igrs.listener;

import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.cg.neel.igrs.external.service.Mail_Service;
import com.cg.neel.igrs.users.UserRegAccessBean;
import com.cg.neel.igrs.users.UserRegDto;



/**
 * @author Preeti
 * @Description Use this listener for sending a confirmation mail 
 *
 */
@Component
public class RegistrationListener implements ApplicationListener<OnRegistrationCompleteEvent>{
	
	@Autowired
	public ModelMapper modelMapper;
	
	@Autowired
	Mail_Service MAIL_SERVICE;

	@Override
	public void onApplicationEvent(final OnRegistrationCompleteEvent event) {
		this.confirmRegistration(event);
	}

	/**
	 * @param event
	 */
	private void confirmRegistration(final OnRegistrationCompleteEvent event) {
		final UserRegAccessBean userRegAccessBean = event.getUserRegAccessBean();
		final String token = UUID.randomUUID().toString();
		
		//@Mail Services -> Sending a mail
		
		//Convert Entity to DTO
		UserRegDto userRegDto = modelMapper.map(userRegAccessBean, UserRegDto.class);

		//GenericResponse response = MAIL_SERVICE.constructEmailMessage(userRegDto,token);
		
		//System.out.println(response);
		//GenericResponse response = constructEmailMessage(event, userRegDto, token);
	}



}
