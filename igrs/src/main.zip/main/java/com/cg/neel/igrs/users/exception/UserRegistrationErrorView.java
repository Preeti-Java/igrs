/**
 * 
 */
package com.cg.neel.igrs.users.exception;

/**
 * @author User
 *
 */
public class UserRegistrationErrorView {

}
