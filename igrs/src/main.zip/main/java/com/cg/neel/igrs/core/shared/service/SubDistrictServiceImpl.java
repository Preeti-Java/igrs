package com.cg.neel.igrs.core.shared.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.neel.igrs.searchdata.SubDistrictAccessBean;

@Service
public class SubDistrictServiceImpl  implements SubDistrictService{
	
	@Override
	public List<SubDistrictAccessBean> getSubDistrictByDistrictId(Long districtId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	

	
	
}
