/**
 * 
 */
package com.cg.neel.igrs.users.service;

/**
 * @author Preeti
 *
 */
public interface UserService {

}
