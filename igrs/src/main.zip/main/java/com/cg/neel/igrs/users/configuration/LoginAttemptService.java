/**
 * 
 */
package com.cg.neel.igrs.users.configuration;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

/**
 * @author Preeti
 * @Description This services used for check attempt for login
 */
@Service
public class LoginAttemptService {
	
	public static final int MAX_ATTEMPT = 10;
	private LoadingCache<String, Integer> atttemptCache;
	
	   @Autowired
	    private HttpServletRequest request;


	/**
	 * @return
	 */
	   
	  
	
	public LoginAttemptService() {
		super();
		atttemptCache = CacheBuilder.newBuilder().expireAfterWrite(1,TimeUnit.DAYS).build(new CacheLoader<String, Integer>(){
			@Override
			public Integer load(String key) throws Exception {
				return 0;
			}
			
		});
	}
	

	//Write method in future
	public boolean isBlocked() {
		  try {
	            return atttemptCache.get(getClientIP()) >= MAX_ATTEMPT;
	        } catch (final ExecutionException e) {
	            return false;
	        }
	}
	
	private String getClientIP(){
		return null;
	}

}
