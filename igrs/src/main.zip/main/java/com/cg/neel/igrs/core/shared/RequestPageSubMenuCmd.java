package com.cg.neel.igrs.core.shared;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.Set;

import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RequestMapping
public interface RequestPageSubMenuCmd {
	
	@GetMapping("/byOwnerMenu")
	ResponseEntity<Map<String, Object>> getByOwnerMenu(@RequestParam("menuId") Long menuId);
	
	@GetMapping("/districtList1")
	ResponseEntity<Set<Object>> getDataList(@RequestParam("menuId") Long menuId,@RequestParam("q") String ch) throws NotFoundException,  IllegalAccessException,NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException;
	
	@GetMapping("/districtList")
	ResponseEntity<Set<Object>> getDataListByMenuValue(@RequestParam Map<String,String> map,@RequestParam("menuId") Long menuId,@RequestParam("q") String ch) throws NotFoundException,  IllegalAccessException,NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException;
	
	
}
