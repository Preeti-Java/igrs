package com.cg.neel.igrs.core.shared.service;



import java.util.List;

import com.cg.neel.igrs.ui.content.MenuAccessBean;


public interface RequestPageService {

	List<MenuAccessBean> getSearchMenu();

}
