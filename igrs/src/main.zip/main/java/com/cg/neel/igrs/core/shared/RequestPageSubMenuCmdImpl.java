package com.cg.neel.igrs.core.shared;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.neel.igrs.core.shared.service.HeaderService;
import com.cg.neel.igrs.searchdata.VillageAccessBean;
import com.cg.neel.igrs.utils.GenericResponse;

@RestController
@RequestMapping("/searchSubMenu")
public class RequestPageSubMenuCmdImpl implements RequestPageSubMenuCmd {
	
	private static final String MENU_NOT_FOUND = "Menu value : ";

	@Autowired
	private HeaderService headerService;

	// This method return all the menu
	// Menu Hierarchy like District -> SubDistrict Always
	@Override
	public ResponseEntity<Map<String, Object>> getByOwnerMenu(final Long menudId) {
		Map<String, Object> menuDto = headerService.getByOwnerMenu(menudId);
		return ResponseEntity.ok().body(menuDto);
	}

	@Override
	public ResponseEntity<Set<Object>> getDataList(final Long menuId, final String ch)
			throws NotFoundException, IllegalAccessException, NoSuchMethodException, SecurityException,
			IllegalArgumentException, InvocationTargetException {
		// First check required -> data or child menu
		if (ch.equals("data")) {
			return ResponseEntity.ok().body(headerService.getDataList(menuId));
		} else if (ch.equals("menu")) {
			Map<String, Object> menuDto = headerService.getByOwnerMenu(menuId);
			Set<Object> data = new LinkedHashSet<>(menuDto.values());
			return ResponseEntity.ok().body(data);
		}
		return ResponseEntity.ok().body(null);

	}

	// Map<key,value> -> key: menuId , value: menuValue(this menuId is a dependency
	// of main menuId which data is required)
	// menuId -> Data required
	// ch -> table data
	@Override
	public ResponseEntity<Set<Object>> getDataListByMenuValue(final Map<String, String> map, final Long menuId,
			final String ch) throws NotFoundException, IllegalAccessException, NoSuchMethodException, SecurityException,
			IllegalArgumentException, InvocationTargetException {
		 //validate value is null or not
        if(menuId == null)
        	 throw new NullPointerException(MENU_NOT_FOUND + menuId);
		
		// First check required -> data or child menu
		if (ch.equals("data")) {
			System.out.println(map);
			return ResponseEntity.ok(headerService.getDataListByMenuValue(map, menuId, ch));
		}
		else if (ch.equals("menu")) {
			Map<String, Object> menuDto = headerService.getByOwnerMenu(menuId);
			Set<Object> data = new LinkedHashSet<>(menuDto.values());
			return ResponseEntity.ok().body(data);
		}

			return ResponseEntity.ok().body(null);
	}

}
