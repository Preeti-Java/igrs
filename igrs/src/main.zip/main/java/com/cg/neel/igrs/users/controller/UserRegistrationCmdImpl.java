/**
 * 
 */
package com.cg.neel.igrs.users.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.neel.igrs.users.UserRegAccessBean;
import com.cg.neel.igrs.users.UserRegDto;
import com.cg.neel.igrs.users.service.RegistrationService;
import com.cg.neel.igrs.utils.GenericResponse;

/**
 * @author   Preeti
 *
 */

@RestController
@RequestMapping("/user")
public class UserRegistrationCmdImpl implements UserRegistrationCmd{
	
	@Autowired
	private RegistrationService registrationService;
	
	@Autowired
	private ApplicationEventPublisher eventPublisher;

	@Override
	public GenericResponse registration( final UserRegDto userRegDto, HttpServletRequest request) {
		
		//Verified your Credential -> mobile No exit, mobile verified, email exit
		final boolean verifiedCred = registrationService.verifiedCreditional(userRegDto);
		if(!verifiedCred)
		{
			return  new GenericResponse("Something isssue");
		}
		 final UserRegAccessBean userReg = registrationService.registerNewUserAccount(userRegDto);
	//	eventPublisher.publishEvent(new OnRegistrationCompleteEvent(Utils.getAppUrl(request), request.getLocale(), userReg));
		//Mail Services -> Sending a mail
		return new GenericResponse("Success");
	}

}
