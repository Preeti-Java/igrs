/**
 * 
 */
package com.cg.neel.igrs.ui.content;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.users.RolesAccessBean;
import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Preeti
 * @Description :  This table show relation between menu bar and roles software with HIndi and English
 *   
 *
 */

@Entity
@Table(name="MENUROLE")
@Getter
@Setter
public class MenuRoleAccessBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MENUROLE_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long menuRoleId;
	
	
	@ManyToOne
	@JoinColumn(name ="roleId")
	@JsonBackReference
	private RolesAccessBean rolesAccessBean;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name ="menuId")
	@JsonBackReference
	private MenuAccessBean menuAccessBean;
	    
}
