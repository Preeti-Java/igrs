/**
 * 
 */
package com.cg.neel.igrs.users.repository;

import javax.validation.Valid;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.neel.igrs.users.MobileVerification;

/**
 * @author Preeti
 *
 */

@RequestMapping
public interface MobileVerificationRepository extends JpaRepository<MobileVerification, Long>{

	/**
	 * @param mobileNumber
	 * @return MobileVerification
	 */
	MobileVerification findByMobileNumber(@Valid String mobileNumber);

	/**
	 * @param latest mobileNumber 
	 * @return MobileVerification
	 */
	MobileVerification findTopByMobileNumber(@Valid String mobileNumber);

	/**
	 * @param mobileNumber
	 */
	void deleteByMobileNumber(@Valid String mobileNumber);

	/**
	 * @param mobileNumber
	 * @return
	 */
	MobileVerification findTopByMobileNumberOrderByMobileVerificationIdDesc(@Valid String mobileNumber);

}
