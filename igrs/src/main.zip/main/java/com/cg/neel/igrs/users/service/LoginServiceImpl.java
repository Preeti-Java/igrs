/**
 * 
 */
package com.cg.neel.igrs.users.service;

import org.springframework.stereotype.Service;

/**
 * @author Preeti
 * 
 *
 */
@Service
public class LoginServiceImpl implements LoginService {

}
